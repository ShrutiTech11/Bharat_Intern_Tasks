# Weather Forecast App

Weather Forecast App also provides atmospheric pressure, weather conditions, visibility distance, relative humidity, precipitation in different unites, dew point, wind speed and direction, in addition to ten days in future and hourly weather forecast.


# Sreenshot 

![](./weather1.JPG)
![](./weather2.JPG)


